package com.example.restfulweb.todo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulWebTodoApplicationTests {

	@Test
	void contextLoads() {
	}

}
