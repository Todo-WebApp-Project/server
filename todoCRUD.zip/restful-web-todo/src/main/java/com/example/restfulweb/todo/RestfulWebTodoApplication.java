package com.example.restfulweb.todo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulWebTodoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulWebTodoApplication.class, args);
	}

}
