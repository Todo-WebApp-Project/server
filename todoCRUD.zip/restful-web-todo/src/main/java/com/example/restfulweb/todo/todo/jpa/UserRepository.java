package com.example.restfulweb.todo.todo.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.restfulweb.todo.todo.user.User;


public interface UserRepository extends JpaRepository<User, Integer> {

}